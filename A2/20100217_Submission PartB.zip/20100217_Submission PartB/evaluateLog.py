#sample run command: python evaluateLog.py log_BB_0.txt
import sys
import argparse
import pprint
import pandas as p

qualityList = []
rebufferList = []
startupDelay = 0
M_IN_K = 1000.0


def calculateQOE(variationWeight, rebufferWeight, startupWeight):
	global qualityList
	global rebufferList
	global startupDelay
	global M_IN_K

	totalQuality = sum(qualityList)
	totalVariation = 0
	for i in range(len(rebufferList) - 1):
		totalVariation += abs(qualityList[i + 1] - qualityList[i])
	totalRebuffer = sum(rebufferList)

	return ((totalQuality / M_IN_K) - (variationWeight * totalVariation / M_IN_K) - (rebufferWeight \
	* totalRebuffer) - (startupWeight * startupDelay), totalQuality, totalVariation, totalRebuffer, startupDelay)

def inputFile(filename):
	global qualityList
	global rebufferList
	global startupDelay
	global M_IN_K
	
	with open(filename, 'r') as f:
		for line in f:
			record = line.split('\t')

			if len(record) > 1:
				qualityList.append(float(record[1]))
				rebufferList.append(float(record[3]))
		qualityList.pop(0)
		startupDelay = rebufferList[0]
		rebufferList.pop(0)

def main():
	global qualityList
	global rebufferList
	global startupDelay
	global M_IN_K
	DICTIONARY = {}
	files = [
				'log_1_c1' ,
				'log_2_c1' ,
				'log_1_c2' ,
				'log_2_c2' , 
				'log_1_w1' ,
				'log_2_w1' , 
				'log_1_w2' ,
				'log_2_w2' , 
				'log_1_w3' ,
				'log_2_w3' , 
				'log_1_w4' ,
				'log_2_w4'
			]

	# filename = sys.argv[1]
	for filename in files:
		try:
			DICTIONARY[filename] = {}
			variationParam = 0.15
			rebufferParam = 0.6
			startupParam = 0.25
			inputFile(filename)
			result = calculateQOE(variationParam, rebufferParam, startupParam)
			obj = {
				"QOE" : str(result[0]),
				"Total Quality" : str(result[1]),
				"Total variation" : str(result[2]),
				"Total rebuffer time" : str(result[3]),
				"Total startupDelay" : str(result[4])
			}
			DICTIONARY[filename] = obj
			qualityList = []
			rebufferList = []
			startupDelay = 0
			M_IN_K = 1000.0
		except:
			pass
	# pprint.pprint(DICTIONARY)
	df = p.DataFrame(DICTIONARY)
	df.to_csv('Algorithms.csv' , sep = '\t')

if __name__ == '__main__':
	main()
